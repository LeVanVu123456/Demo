package BaiTap7;

public class bai72 {
	 public static void main(String[] args) {
	        PolyLine polyline = new PolyLine();
	        polyline.appendPoint(1, 2);
	        polyline.appendPoint(3, 4);
	        polyline.appendPoint(new Point(5, 6));

	        System.out.println(polyline);
	        System.out.println("Length: " + polyline.getLength());
	    }
}
