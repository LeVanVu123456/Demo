package BaiTap6;

public interface Resizable {
	void resize(int percent);
}
