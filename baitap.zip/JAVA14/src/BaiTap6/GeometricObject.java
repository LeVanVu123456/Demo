package BaiTap6;

public interface GeometricObject {
	double getArea();
    double getPerimeter();
}
