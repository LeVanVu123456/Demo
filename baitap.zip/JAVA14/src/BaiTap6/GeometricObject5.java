package BaiTap6;

public interface GeometricObject5 {
	 double getPerimeter();
	    double getArea();
}
