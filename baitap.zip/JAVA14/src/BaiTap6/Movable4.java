package BaiTap6;

public interface Movable4 {
	void moveUp();
    void moveDown();
    void moveLeft();
    void moveRight();
}
