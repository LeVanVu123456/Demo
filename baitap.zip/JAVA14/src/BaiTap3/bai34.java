package BaiTap3;

public class bai34 {
	 public static void main(String[] args) {
	        MyTime time = new MyTime(23, 59, 59);
	        System.out.println("Current time: " + time);

	        time.nextSecond();
	        System.out.println("After next second: " + time);

	        time.nextMinute();
	        System.out.println("After next minute: " + time);

	        time.nextHour();
	        System.out.println("After next hour: " + time);

	        time.previousSecond();
	        System.out.println("After previous second: " + time);

	        time.previousMinute();
	        System.out.println("After previous minute: " + time);

	        time.previousHour();
	        System.out.println("After previous hour: " + time);
	    }
}
