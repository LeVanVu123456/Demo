package BaiTap;

public class Rectangle {
    private float width ;
    private float length ;
	public Rectangle() {
		width = 1.0f;
		length =  1.0f;
	}
	public Rectangle(float width, float length) {
		super();
		this.width = width;
		this.length = length;
	}
	public float getWidth() {
		return width;
	}
	public void setWidth(float width) {
		this.width = width;
	}
	public float getLength() {
		return length;
	}
	public void setLength(float length) {
		this.length = length;
	}
	
    public double getPerimeter() {
    	return (length + width)* 2;
    }
    public double getArea() {
    	return length * width ;
    }
    public String toString() {
    	return "Rectangle [width= " + width + " length="+ length ;
    }
  
}
