package BaiTap;

public class text {
	 public static void main(String[] args) {
	      // Test constructor and toString()
	      ngay d1 = new ngay(0, 0, 0);
	      System.out.println(d1);  // toString()

	      // Test Setters and Getters
	      d1.setMonth(12);
	      d1.setDay(9);
	      d1.setYear(2099);
	      System.out.println(d1);  // toString()
	      System.out.println("Month: " + d1.getMonth());
	      System.out.println("Day: " + d1.getDay());
	      System.out.println("Year: " + d1.getYear());

	      // Test setDate()
	      d1.setData(3, 4, 2016);
	      System.out.println(d1);  // toString()
	   }
}
