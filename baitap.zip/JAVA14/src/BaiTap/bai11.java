   package BaiTap;
   
   
  public class bai11 {
  private double radius;
  private String close ;
  
  

public bai11() {
	radius = 1.0;
    close = "red";
}



public bai11(double radius, String close) {
	
	radius = 1.0;
	close = "red";
}



public double getRadius() {
	return radius;
}

public String getClose() {
	return close;
}

public void setClose(String close) {
	this.close = close;
}
 public double getArea() {
	 return radius*radius*Math.PI;
 }
 }
