package BaiTap;

public class Circle {
   private double radius;
   private String color;
public Circle() {
	radius=2;
	color = "red";
}
public Circle(double r) {
	radius = r;
	color = "red";
	
}
public Circle(double r, String c) {
	super();
	this.radius = r;
	this.color = c;
}
public double getRadius() {
	return radius;
}
public void setRadius(double radius) {
	this.radius = radius;
}
public String getColor() {
	return color;
}
public void setColor(String color) {
	this.color = color;
}

public String toString() {
	return "Circle[radius" + radius + "]";
}
public double getCircumference() {
	return 2*Math.PI*radius;
}
public double getArea() {
	return radius*radius*Math.PI;
}
}
